#!/bin/bash

mvn clean
