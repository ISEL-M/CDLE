package myminecraft.myminecraft;

import net.fabricmc.api.ModInitializer;

public class MyMinecraft implements ModInitializer {
    @Override
    public void onInitialize() {

    }
}
