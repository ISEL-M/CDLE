#!/bin/bash

source 01-hadoopDefs.sh

declare -a CommandsStartHDFS=(	
	"${HADOOP_HOME}/sbin/start-dfs.sh" 
	"jps"
)

declare -a CommandsStartYARN=(
	"${HADOOP_HOME}/sbin/start-yarn.sh" 
	"jps"
)

declare -a CommandsStartMR=(
	"${HADOOP_HOME}/bin/mapred --daemon start historyserver" 
	"jps"
)

showMessageWithTimeout "Press ENTER to start HDFS services"
for currentCommand in "${CommandsStartHDFS[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_HDFS} ssh ${SSH_OPTIONS} ${HADOOP_USER_HDFS}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done

showMessageWithTimeout "Press ENTER to start YARN services"
for currentCommand in "${CommandsStartYARN[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_YARN} ssh ${SSH_OPTIONS} ${HADOOP_USER_YARN}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done

showMessageWithTimeout "Press ENTER to start MapReduce services"
for currentCommand in "${CommandsStartMR[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_MR} ssh ${SSH_OPTIONS} ${HADOOP_USER_MR}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done
