#!/bin/bash

source 01-hadoopDefs.sh

echo -e "Removing HDFS from service at boot time..."
removeService ${HDFS_SYSTEMD_SERVICE_FILE} ${HDFS_SYSTEMD_SERVICE_FILE} ${SYSTEMD_SERVICE_DIRECTORY}

echo -e "Removing YARN from service at boot time..."
removeService ${YARN_SYSTEMD_SERVICE_FILE} ${YARN_SYSTEMD_SERVICE_FILE} ${SYSTEMD_SERVICE_DIRECTORY}

echo -e "Removing MapReduce from service at boot time..."
removeService ${MAPREDUCE_SYSTEMD_SERVICE_FILE} ${MAPREDUCE_SYSTEMD_SERVICE_FILE} ${SYSTEMD_SERVICE_DIRECTORY}
