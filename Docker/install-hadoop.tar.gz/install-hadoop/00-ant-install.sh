#!/bin/bash

ANT_ENV_SH=/etc/profile.d/ant.sh
ANT_ENV_CSH=/etc/profile.d/ant.csh

echo -e "\nUpdating local repositories..."
sudo apt update

echo -e "\nInstalling ant..."
sudo apt install ant

PathToANT=`find /usr/share/ant/bin -name ant `

Path1=`dirname ${PathToANT}`
ANT_HOME=`dirname ${Path1}`

export ANT_HOME

echo "ANT_HOME is going to be set to ${ANT_HOME}"

echo -e "\nSetting ANT environment for shell..."

CMD="echo 'export ANT_HOME=${ANT_HOME}' > ${ANT_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export ANT_HOME=${ANT_HOME}' > ${ANT_ENV_SH}"

CMD="echo 'export PATH=\${PATH}:${ANT_HOME}/bin' >> ${ANT_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export PATH=${ANT_HOME}/bin:\${PATH}' >> ${ANT_ENV_SH}"

CMD="chmod +x ${ANT_ENV_SH}"
echo "sudo ${CMD}"
sudo ${CMD}

echo -e "ANT environment for shell:\n"
cat ${ANT_ENV_SH}

echo -e "\n\nSetting ANT environment for cshell..."

CMD="echo 'setenv ANT_HOME ${ANT_HOME}' > ${ANT_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv ANT_HOME ${ANT_HOME}' > ${ANT_ENV_CSH}"

CMD="echo 'setenv PATH ${ANT_HOME}/bin:\${PATH}' >> ${ANT_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv PATH ${ANT_HOME}/bin:\${PATH}' >> ${ANT_ENV_CSH}"

CMD="chmod +x ${ANT_ENV_CSH}"
echo "sudo ${CMD}"
sudo ${CMD}

echo -e "ANT environment for cshell:\n"
cat ${ANT_ENV_CSH}

echo ""
