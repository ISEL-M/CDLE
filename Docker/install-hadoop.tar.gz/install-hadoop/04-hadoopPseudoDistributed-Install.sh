#!/bin/bash

source 01-hadoopDefs.sh

02-hadoopStandAlone-Install.sh

showMessageWithTimeout "Press ENTER to create Hadoop group"

echo -e "\nCreating group (${HADOOP_GROUP})..."
CMD="sudo groupadd ${HADOOP_GROUP}"
echo -e ${CMD}
${CMD}

showMessageWithTimeout "Press ENTER to create Hadoop services accounts"

echo -e "\nCreating user accounts for Hadoop services..."

createUser ${HADOOP_USER_MR} "MapReduce" ${HADOOP_PASS_MR}
createUser ${HADOOP_USER_HDFS} "HDFS" ${HADOOP_PASS_HDFS}
createUser ${HADOOP_USER_YARN} "Yarn" ${HADOOP_PASS_YARN}

showMessageWithTimeout "Press ENTER to create Hadoop HDFS data directory"
createHadoopDataDirectory

showMessageWithTimeout "Press ENTER to change owner of Hadoop installation files"

echo -e "\nChange the owner of the Hadoop files to user (${HADOOP_USER_MR})..."
CMD="chown -R ${HADOOP_USER_MR}:${HADOOP_GROUP} ${HADOOP_BASE_DIRECTORY}/${HADOOP_RELEASE_NAME}"
echo -e "sudo ${CMD}"
sudo ${CMD}

showMessageWithTimeout "Press ENTER to change write permissions on Hadoop installation files"

echo -e "\nAdding write permission to the Hadoop files to group (${HADOOP_GROUP})..."
CMD="chmod -R g+w ${HADOOP_BASE_DIRECTORY}/${HADOOP_RELEASE_NAME}"
echo -e "sudo ${CMD}"
sudo ${CMD}

showMessageWithTimeout "Press ENTER to setup Hadoop environment in pseudo distributed mode"
setHadoopEnvironment

showMessageWithTimeout "Press ENTER to create Hadoop log4java properties files"

echo -e "\nConfiguration log4java properties..."
CMD="cp ${HADOOP_HOME}/etc/hadoop/log4j.properties ${HADOOP_CONF_DIR}"
echo -e "sudo ${CMD}"
sudo ${CMD}

echo -e "\nCreating configuration definitions"

echo -e "Saving current IFS..."
CurrentIFS=${IFS}

IFS='' read -r -d '' __workers << EOM
localhost
EOM

IFS='' read -r -d '' __settingsCore << EOM
<configuration>
	<property>
		<name>hadoop.tmp.dir</name>
		<value>${HADOOP_BASE_TMP_DIRECORY}/hadoop-\${user.name}</value>
	</property>
	<property>
		<name>fs.defaultFS</name>
		<value>hdfs://${DFS_NAMENODE_HOST}:${DFS_NAMENODE_PORT}</value>
	</property>
</configuration>
EOM

IFS='' read -r -d '' __settingsHDFS << EOM
<configuration>
	<property>
		<name>dfs.replication</name>
		<value>${HDFS_REPLICATION}</value>
	</property>

	<property>
		<name>fs.permissions.umask-mode</name>
		<value>002</value>
	</property>

	<property>
		<name>dfs.namenode.data.dir</name>
		<value>file://${HADOOP_DATA_DIRECORY_NAMENODE}</value>
	</property>
	
	<property>
		<name>dfs.datanode.data.dir</name>
		<value>file://${HADOOP_DATA_DIRECORY_DATANODE}</value>
	</property>
	
	<property>
		<name>dfs.permissions.superusergroup</name>
		<value>${HADOOP_GROUP}</value>
	</property>

	<property>
		<name>dfs.namenode.http-address</name>
		<!-- <value>${DFS_NAMENODE_HTTP_NAME}:${WebUI_HTTP_NAMENODE_HDFS}</value> -->
		<value>${DFS_NAMENODE_HTTP_NAME_DOCKER}:${WebUI_HTTP_NAMENODE_HDFS}</value>
	</property>
	<!--
	<property>
		<name>dfs.namenode.https-address</name>
		<value>${DFS_NAMENODE_HTTP_NAME}:${WebUI_HTTPS_NAMENODE_HDFS}</value>
	</property>
	-->
	
	<property>
		<name>dfs.namenode.secondary.http-address</name>
		<!--<value>${DFS_SECONDARYNAMENODE_HTTP_NAME}:${WebUI_HTTP_SECONDARYNAMENODE_HDFS}</value>-->
		<value>${DFS_SECONDARYNAMENODE_HTTP_NAME_DOCKER}:${WebUI_HTTP_SECONDARYNAMENODE_HDFS}</value>
	</property>
	<!--
	<property>
		<name>dfs.namenode.secondary.https-address</name>
		<value>${DFS_SECONDARYNAMENODE_HTTP_NAME}:${WebUI_HTTPS_SECONDARYNAMENODE_HDFS}</value>
	</property>
	-->
	
	<property>
		<name>dfs.datanode.http.address</name>
		<!--<value>${DFS_DATANODE_HTTP_NAME}:${WebUI_HTTP_DATANODE_HDFS}</value>-->
		<value>${DFS_DATANODE_HTTP_NAME_DOCKER}:${WebUI_HTTP_DATANODE_HDFS}</value>
	</property>
	<!--
	<property>
		<name>dfs.datanode.https.address</name>
		<value>${DFS_DATANODE_HTTP_NAME}:${WebUI_HTTPS_DATANODE_HDFS}</value>
	</property>
	-->
</configuration>
EOM

IFS='' read -r -d '' __settingsMR << EOM
<configuration>
	<property>
		<name>mapreduce.framework.name</name>
		<value>yarn</value>
	</property>
	
	<property>
		<name>mapreduce.jobhistory.webapp.address</name>
		<!--<value>${MR_HTTP_NAME}:${WebUI_HTTP_MR}</value>-->
		<value>${MR_HTTP_NAME_DOCKER}:${WebUI_HTTP_MR}</value>
	</property>
	<!--
	<property>
		<name>mapreduce.jobhistory.webapp.https.address</name>
		<value>${MR_HTTP_NAME}:${WebUI_HTTPS_MR}</value>
	</property>
	-->
	
	<property>
		<name>yarn.app.mapreduce.am.env</name>
		<value>${HADOOP_MAPRED_HOME}</value>
	</property>
	<property>
		<name>mapreduce.map.env</name>
		<value>${HADOOP_MAPRED_HOME}</value>
	</property>
	<property>
		<name>mapreduce.reduce.env</name>
		<value>${HADOOP_MAPRED_HOME}</value>
	</property>
	
	<property>
		<name>mapreduce.application.classpath</name>
		<value>${HADOOP_MAPRED_HOME}/share/hadoop/mapreduce/*,${HADOOP_MAPRED_HOME}/share/hadoop/mapreduce/lib/*</value>
	</property>
	
</configuration>
EOM

IFS='' read -r -d '' __settingsYARN << EOM
<configuration>
	<property>
		<name>yarn.resourcemanager.hostname</name>
		<value>${YARN_RM_HOSTNAME}</value>
	</property>
	<property>
		<name>yarn.nodemanager.aux-services</name>
		<value>mapreduce_shuffle</value>
	</property>
	
	<property>
		<name>yarn.resourcemanager.webapp.address</name>
		<!--<value>${YARN_RM_HTTP_NAME}:${WebUI_HTTP_YARN_RM}</value>-->
		<value>${YARN_RM_HTTP_NAME_DOCKER}:${WebUI_HTTP_YARN_RM}</value>
	</property>
	<!--
	<property>
		<name>yarn.resourcemanager.webapp.https.address</name>
		<value>${YARN_RM_HTTP_NAME}:${WebUI_HTTPS_YARN_RM}</value>
	</property>
	-->
	
	<property>
		<name>yarn.nodemanager.webapp.address</name>
		<!--<value>${YARN_NM_HTTP_NAME}:${WebUI_HTTP_YARN_NM}</value>-->
		<value>${YARN_NM_HTTP_NAME_DOCKER}:${WebUI_HTTP_YARN_NM}</value>
	</property>
	<!--	
	<property>
		<name>yarn.nodemanager.webapp.https.address</name>
		<value>${YARN_NM_HTTP_NAME}:${WebUI_HTTPS_YARN_NM}</value>
	</property>
	-->
	
	<property>
		<name>yarn.nodemanager.vmem-check-enabled</name>
		<value>false</value>
	</property>
</configuration>
EOM

IFS='' read -r -d '' __settingsQueues << EOM
<configuration>
	<property>
		<name>yarn.scheduler.capacity.root.queues</name>
		<value>default</value>
		<description>The queues at the this level (root is the root queue).</description>
	</property>
	<property>
		<name>yarn.scheduler.capacity.root.default.capacity</name>
		<value>100</value>
		<description>Default queue target capacity.</description>
	</property>
</configuration>
EOM

echo -e "Restoring IFS..."
IFS=${currentIFS}

showMessageWithTimeout "Press ENTER to configure workers nodes file (${FILE_NODES_WORKERS})"
createNodesFile ${__workers} "Workers" ${FILE_NODES_WORKERS} ${HADOOP_CONF_DIR}

showMessageWithTimeout "Press ENTER to configure settings in file core-site(.xml)"
createServiceConfigFile ${__settingsCore} "Hadoop" "core-site.xml" ${HADOOP_CONF_DIR}

showMessageWithTimeout "Press ENTER to configure settings in file hdfs-site(.xml)"
createServiceConfigFile ${__settingsHDFS} "HDFS" "hdfs-site.xml" ${HADOOP_CONF_DIR}

showMessageWithTimeout "Press ENTER to configure settings in file mapred-site(.xml)"
createServiceConfigFile ${__settingsMR} "MapReduce" "mapred-site.xml" ${HADOOP_CONF_DIR}

showMessageWithTimeout "Press ENTER to configure settings in file yarn-site(.xml)"
createServiceConfigFile ${__settingsYARN} "Yarn" "yarn-site.xml" ${HADOOP_CONF_DIR}

showMessageWithTimeout "Press ENTER to configure settings in file capacity-scheduler(.xml)"
createServiceConfigFile ${__settingsQueues} "Yarn" "capacity-scheduler.xml" ${HADOOP_CONF_DIR}

showMessageWithTimeout "Press ENTER to show Hadoop version"

showHadoopVersion

showMessageWithTimeout "Press ENTER to finish pseudo distributed installation"
