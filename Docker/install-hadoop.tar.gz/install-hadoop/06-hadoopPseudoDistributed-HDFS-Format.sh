#!/bin/bash

source 01-hadoopDefs.sh

declare -a CommandsFormat=(
	"${HADOOP_HOME}/bin/hdfs namenode -format"
)	

showMessageWithTimeout "Press ENTER to format Hadoop file system (HDFS)"

for currentCommand in "${CommandsFormat[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_HDFS} ssh ${SSH_OPTIONS} ${HADOOP_USER_HDFS}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done
