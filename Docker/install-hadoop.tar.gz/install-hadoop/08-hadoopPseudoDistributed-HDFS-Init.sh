#!/bin/bash

source 01-hadoopDefs.sh

declare -a CommandsInitHDFS=(	
	"${HADOOP_HOME}/bin/hadoop fs -mkdir -p /tmp"
	"${HADOOP_HOME}/bin/hadoop fs -chmod -R 0777 /tmp"
	"${HADOOP_HOME}/bin/hadoop fs -mkdir -p /user/history"
	"${HADOOP_HOME}/bin/hadoop fs -chmod -R 0777 /user/history"
	"${HADOOP_HOME}/bin/hadoop fs -chown ${HADOOP_USER_MR}:${HADOOP_GROUP} /user/history"
)

showMessageWithTimeout "Press ENTER to create contents inside HDFS"
for currentCommand in "${CommandsInitHDFS[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_HDFS} ssh ${SSH_OPTIONS} ${HADOOP_USER_HDFS}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done
