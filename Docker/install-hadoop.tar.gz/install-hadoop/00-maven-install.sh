#!/bin/bash

MAVEN_ENV_SH=/etc/profile.d/mvn.sh
MAVEN_ENV_CSH=/etc/profile.d/mvn.csh

echo -e "\nUpdating local repositories..."
sudo apt update

echo -e "\nInstalling maven..."
sudo apt install maven

PathToMaven=`find /usr/share/maven -name mvn `

Path1=`dirname ${PathToMaven}`
MAVEN_HOME=`dirname ${Path1}`

export MAVEN_HOME

echo "MAVEN_HOME is going to be set to ${MAVEN_HOME}"

echo -e "\nSetting Maven environment for shell..."

CMD="echo 'export MAVEN_HOME=${MAVEN_HOME}' > ${MAVEN_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export MAVEN_HOME=${MAVEN_HOME}' > ${MAVEN_ENV_SH}"

CMD="echo 'export PATH=\${PATH}:${MAVEN_HOME}/bin' >> ${MAVEN_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export PATH=${MAVEN_HOME}/bin:\${PATH}' >> ${MAVEN_ENV_SH}"

CMD="chmod +x ${MAVEN_ENV_SH}"
echo "sudo ${CMD}"
sudo ${CMD}

echo -e "Maven environment for shell:\n"
cat ${MAVEN_ENV_SH}

echo -e "\n\nSetting Maven environment for cshell..."

CMD="echo 'setenv MAVEN_HOME ${MAVEN_HOME}' > ${MAVEN_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv MAVEN_HOME ${MAVEN_HOME}' > ${MAVEN_ENV_CSH}"

CMD="echo 'setenv PATH ${MAVEN_HOME}/bin:\${PATH}' >> ${MAVEN_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv PATH ${MAVEN_HOME}/bin:\${PATH}' >> ${MAVEN_ENV_CSH}"

CMD="chmod +x ${MAVEN_ENV_CSH}"
echo "sudo ${CMD}"
sudo ${CMD}

echo -e "Maven environment for cshell:\n"
cat ${MAVEN_ENV_CSH}

echo ""
