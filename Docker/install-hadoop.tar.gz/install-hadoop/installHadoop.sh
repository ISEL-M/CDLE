#!/bin/bash

04-hadoopPseudoDistributed-Install.sh | tee ~/installHadoop.log

06-hadoopPseudoDistributed-HDFS-Format.sh 2>&1 | tee -a ~/installHadoop.log

07-hadoopPseudoDistributed-Start.sh 2>&1 | tee -a ~/installHadoop.log

08-hadoopPseudoDistributed-HDFS-Init.sh 2>&1 | tee -a ~/installHadoop.log

09-hadoopPseudoDistributed-ShowUI.sh 2>&1 | tee -a ~/installHadoop.log
