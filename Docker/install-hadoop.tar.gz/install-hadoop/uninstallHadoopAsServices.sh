#!/bin/bash

10-hadoopPseudoDistributed-Stop.sh 2>&1 | tee ~/uninstallHadoopAsServices.log

05-hadoopPseudoDistributed-Erase.sh 2>&1 | tee -a ~/uninstallHadoopAsServices.log

14-hadoop-EraseServicesOnBoot.sh 2>&1 | tee -a ~/uninstallHadoopAsServices.log