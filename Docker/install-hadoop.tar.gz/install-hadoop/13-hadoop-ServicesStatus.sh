#!/bin/bash

source 01-hadoopDefs.sh

echo -e "HDFS service status..."
systemctl status ${HDFS_SYSTEMD_SERVICE_FILE} | grep "Active"

echo -e "YARN service status..."
systemctl status ${YARN_SYSTEMD_SERVICE_FILE} | grep "Active"

echo -e "MapReduce service status..."
systemctl status ${MAPREDUCE_SYSTEMD_SERVICE_FILE} | grep "Active"
