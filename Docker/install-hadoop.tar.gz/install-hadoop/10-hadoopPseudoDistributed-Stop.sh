#!/bin/bash

source 01-hadoopDefs.sh

declare -a CommandsStopMR=(
	"${HADOOP_HOME}/bin/mapred --daemon stop historyserver"
)

declare -a CommandsStopYARN=(
	"${HADOOP_HOME}/sbin/stop-yarn.sh"
)

declare -a CommandsStopHDFS=(
	"${HADOOP_HOME}/sbin/stop-dfs.sh"
)

showMessageWithTimeout "Press ENTER to stop MapReduce services"
for currentCommand in "${CommandsStopMR[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_MR} ssh ${SSH_OPTIONS} ${HADOOP_USER_MR}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done

showMessageWithTimeout "Press ENTER to stop YARN services"
for currentCommand in "${CommandsStopYARN[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_YARN} ssh ${SSH_OPTIONS} ${HADOOP_USER_YARN}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done

showMessageWithTimeout "Press ENTER to stop HDFS services"
for currentCommand in "${CommandsStopHDFS[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_HDFS} ssh ${SSH_OPTIONS} ${HADOOP_USER_HDFS}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done
