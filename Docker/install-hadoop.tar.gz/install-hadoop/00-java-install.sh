#!/bin/bash

JAVA_ENV_SH=/etc/profile.d/jdk.sh
JAVA_ENV_CSH=/etc/profile.d/jdk.csh

echo -e "\nUpdating local repositories..."
sudo apt update

echo -e "\nInstalling openjdk-8..."
sudo apt install openjdk-8-jdk-headless

PathToJava=`find /usr/lib/ -name java | grep -v "jre" | grep "8" | grep "open"`

Path1=`dirname ${PathToJava}`
JAVA_HOME=`dirname ${Path1}`

export JAVA_HOME

echo "JAVA_HOME is going to be set to ${JAVA_HOME}"

echo -e "\nSetting JDK environment for shell..."

#
# export JAVA_HOME=...
#
CMD="echo 'export JAVA_HOME=${JAVA_HOME}' > ${JAVA_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export JAVA_HOME=${JAVA_HOME}' > ${JAVA_ENV_SH}"

#
# export PATH=...
#
CMD="echo 'export PATH=\${PATH}:${JAVA_HOME}/bin' >> ${JAVA_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export PATH=${JAVA_HOME}/bin:\${PATH}' >> ${JAVA_ENV_SH}"

#
# export JAVA_AWT_LIBRARY=...
#
CMD="echo 'export JAVA_AWT_LIBRARY=${JAVA_HOME}/lib/amd64/libjawt.so' >> ${JAVA_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export JAVA_AWT_LIBRARY=${JAVA_HOME}/lib/amd64/libjawt.so' >> ${JAVA_ENV_SH}"

#
# export JAVA_JVM_LIBRARY=...
#
CMD="echo 'export JAVA_JVM_LIBRARY=${JAVA_HOME}/jre/lib/amd64/server/libjvm.so' >> ${JAVA_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export JAVA_JVM_LIBRARY=${JAVA_HOME}/jre/lib/amd64/server/libjvm.so' >> ${JAVA_ENV_SH}"

#
# export JAVA_INCLUDE_PATH=...
#
CMD="echo 'export JAVA_INCLUDE_PATH=${JAVA_HOME}/include' >> ${JAVA_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export JAVA_INCLUDE_PATH=${JAVA_HOME}/include' >> ${JAVA_ENV_SH}"

#
# export JAVA_INCLUDE_PATH2=...
#
CMD="echo 'export JAVA_INCLUDE_PATH2=${JAVA_HOME}/include/linux' >> ${JAVA_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export JAVA_INCLUDE_PATH2=${JAVA_HOME}/include/linux' >> ${JAVA_ENV_SH}"

#
# export JAVA_AWT_INCLUDE_PATH=...
#
CMD="echo 'export JAVA_AWT_INCLUDE_PATH=${JAVA_HOME}/include' >> ${JAVA_ENV_SH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'export JAVA_AWT_INCLUDE_PATH=${JAVA_HOME}/include' >> ${JAVA_ENV_SH}"

CMD="chmod +x ${JAVA_ENV_SH}"
echo "sudo ${CMD}"
sudo ${CMD}

echo -e "JDK environment for shell:\n"
cat ${JAVA_ENV_SH}

echo -e "\n\nSetting JDK environment for cshell..."

#
# setenv JAVA_HOME=...
#
CMD="echo 'setenv JAVA_HOME ${JAVA_HOME}' > ${JAVA_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv JAVA_HOME ${JAVA_HOME}' > ${JAVA_ENV_CSH}"

#
# setenv PATH=...
#
CMD="echo 'setenv PATH ${JAVA_HOME}/bin:\${PATH}' >> ${JAVA_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv PATH ${JAVA_HOME}/bin:\${PATH}' >> ${JAVA_ENV_CSH}"

#
# setenv JAVA_AWT_LIBRARY=...
#
CMD="echo 'setenv JAVA_AWT_LIBRARY ${JAVA_HOME}/lib/amd64/libjawt.so' >> ${JAVA_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv JAVA_AWT_LIBRARY ${JAVA_HOME}/lib/amd64/libjawt.so' >> ${JAVA_ENV_CSH}"

#
# setenv JAVA_JVM_LIBRARY=...
#
CMD="echo 'setenv JAVA_JVM_LIBRARY ${JAVA_HOME}/jre/lib/amd64/server/libjvm.so' >> ${JAVA_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv JAVA_JVM_LIBRARY ${JAVA_HOME}/jre/lib/amd64/server/libjvm.so' >> ${JAVA_ENV_CSH}"

#
# setenv JAVA_INCLUDE_PATH=...
#
CMD="echo 'setenv JAVA_INCLUDE_PATH ${JAVA_HOME}/include' >> ${JAVA_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv JAVA_INCLUDE_PATH ${JAVA_HOME}/include' >> ${JAVA_ENV_CSH}"

#
# setenv JAVA_INCLUDE_PATH2=...
#
CMD="echo 'setenv JAVA_INCLUDE_PATH2 ${JAVA_HOME}/include/linux' >> ${JAVA_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv JAVA_INCLUDE_PATH2 ${JAVA_HOME}/include/linux' >> ${JAVA_ENV_CSH}"

#
# setenv JAVA_AWT_INCLUDE_PATH=...
#
CMD="echo 'setenv JAVA_AWT_INCLUDE_PATH ${JAVA_HOME}/include' >> ${JAVA_ENV_CSH}"
echo "sudo bash -c \"${CMD}\""
sudo bash -c "echo 'setenv JAVA_AWT_INCLUDE_PATH ${JAVA_HOME}/include' >> ${JAVA_ENV_CSH}"

CMD="chmod +x ${JAVA_ENV_CSH}"
echo "sudo ${CMD}"
sudo ${CMD}

echo -e "JDK environment for cshell:\n"
cat ${JAVA_ENV_CSH}

echo ""
