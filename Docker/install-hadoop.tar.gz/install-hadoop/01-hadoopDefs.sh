#!/bin/bash

HADOOP_BASE_DIRECTORY=/work/hadoop

HADOOP_DATA_DIRECORY=/work/hadoop/HDFS

HADOOP_DATA_DIRECORY_NAMENODE=${HADOOP_DATA_DIRECORY}/namenode
HADOOP_DATA_DIRECORY_DATANODE=${HADOOP_DATA_DIRECORY}/datanode

HADOOP_BASE_TMP_DIRECORY=${HADOOP_DATA_DIRECORY}/tmp

HADOOP_HOME=${HADOOP_BASE_DIRECTORY}/hadoop
HADOOP_MAPRED_HOME=${HADOOP_HOME}

HADOOP_GROUP=hadoop

HADOOP_USER_MR=hadoop
HADOOP_USER_HDFS=hdfs
HADOOP_USER_YARN=yarn

HADOOP_PASS_MR=${HADOOP_USER_MR}
HADOOP_PASS_HDFS=${HADOOP_USER_HDFS}
HADOOP_PASS_YARN=${HADOOP_USER_YARN}

CURRENT_DIRECTORY=`pwd`

#HADOOP_VERSION=3.1.2
#HADOOP_VERSION=3.2.0
HADOOP_VERSION=3.3.1

HADOOP_TAR_BALL=https://archive.apache.org/dist/hadoop/common/hadoop-${HADOOP_VERSION}/hadoop-${HADOOP_VERSION}.tar.gz
HADOOP_RELEASE=`basename ${HADOOP_TAR_BALL}`
HADOOP_RELEASE_NAME=`basename ${HADOOP_RELEASE} .tar.gz`

HADOOP_CONF_DIR=/etc/hadoop
HADOOP_CONF_FILE=${HADOOP_CONF_DIR}/hadoop-env.sh

HADOOP_ENV_SH=/etc/profile.d/hadoop.sh
HADOOP_ENV_CSH=/etc/profile.d/hadoop.csh

FILE_NODES_WORKERS=workers

HDFS_REPLICATION=1

DFS_NAMENODE_HOST=localhost
DFS_NAMENODE_PORT=8020

DFS_NAMENODE_HTTP_NAME=localhost
DFS_NAMENODE_HTTP_NAME_DOCKER=0.0.0.0

DFS_SECONDARYNAMENODE_HTTP_NAME=localhost
DFS_SECONDARYNAMENODE_HTTP_NAME_DOCKER=0.0.0.0

DFS_DATANODE_HTTP_NAME=localhost
DFS_DATANODE_HTTP_NAME_DOCKER=0.0.0.0

YARN_RM_HOSTNAME=localhost

MR_HTTP_NAME=localhost
MR_HTTP_NAME_DOCKER=0.0.0.0

YARN_RM_HTTP_NAME=localhost
YARN_RM_HTTP_NAME_DOCKER=0.0.0.0

YARN_NM_HTTP_NAME=localhost
YARN_NM_HTTP_NAME_DOCKER=0.0.0.0

WebUI_HTTP_NAMENODE_HDFS=9870
WebUI_HTTPS_NAMENODE_HDFS=9871

WebUI_HTTP_SECONDARYNAMENODE_HDFS=9868
WebUI_HTTPS_SECONDARYNAMENODE_HDFS=9869

WebUI_HTTP_DATANODE_HDFS=9864
WebUI_HTTPS_DATANODE_HDFS=9865

WebUI_HTTP_MR=19888
WebUI_HTTPS_MR=19890

WebUI_HTTP_YARN_RM=8088
WebUI_HTTPS_YARN_RM=8090

WebUI_HTTP_YARN_NM=8042
WebUI_HTTPS_YARN_NM=8044

MESSAGE_TIMEOUT=3

SECURE_MODE=false

SSH_OPTIONS="-o StrictHostKeyChecking=no"

SYSTEMD_SERVICE_DIRECTORY=/etc/systemd/system

HDFS_SYSTEMD_SERVICE_FILE=hdfs.service
YARN_SYSTEMD_SERVICE_FILE=yarn.service
MAPREDUCE_SYSTEMD_SERVICE_FILE=mapreduce.service

function showMessageAndWait() {
	_MESSAGE=$1
	
	echo -e "\n${_MESSAGE}"
	read x
}

function showMessageWithTimeout() {
	_MESSAGE=$1
	
	read -t ${MESSAGE_TIMEOUT} -p "Wait ${MESSAGE_TIMEOUT} seconds or, ${_MESSAGE}"
	echo -e "\n"
}

function checkSoftware() {
	if ! [ -x "$(command -v $1)" ]; then
		echo -e "$1 is not installed. Going to install it."
		#exit 1
		sudo apt install $1
	fi

	echo -e "$1 is installed.";
}

function showJavaEnvironment() {
	echo -e "\nJava environment"
	
	echo -e "JAVA_HOME set to ${JAVA_HOME}\n"
	
	${JAVA_HOME}/bin/java -version
}

function showMavenEnvironment() {
	echo -e "\nMaven environment"
	
	echo -e "MAVEN_HOME set to ${MAVEN_HOME}\n"
	
	${MAVEN_HOME}/bin/mvn -version
}

function downloadHadoopTarball() {
	echo -e "\nDownloading Hadoop tar ball (${HADOOP_TAR_BALL})..."
	CMD="wget ${HADOOP_TAR_BALL} --output-document=/tmp/${HADOOP_RELEASE}"
	echo -e ${CMD}
	${CMD}
}

function installHadoopTarball() {
	echo -e "\nInstalling Hadoop to ${HADOOP_HOME}..."

	CMD="sudo mkdir -p ${HADOOP_BASE_DIRECTORY}"
	echo -e ${CMD}
	${CMD}
	
	echo -e "\nChanging to directory ${HADOOP_BASE_DIRECTORY}..."
	CMD="cd ${HADOOP_BASE_DIRECTORY}"
	echo -e ${CMD}
	${CMD}

	echo -e "\nUntaring Hadoop..."
	CMD="sudo tar -xzf /tmp/${HADOOP_RELEASE}"
	echo -e "${CMD}"
	${CMD}

	echo -e "\nRemoving Hadoop tar ball..."
	CMD="rm /tmp/${HADOOP_RELEASE}"
	${CMD}

	echo -e "\nCreating link name..."
	CMD="sudo ln -s ${HADOOP_BASE_DIRECTORY}/${HADOOP_RELEASE_NAME} ${HADOOP_HOME}"
	echo -e ${CMD}
	${CMD}

	echo -e "\nCreating log directory..."
	CMD="sudo mkdir -p ${HADOOP_BASE_DIRECTORY}/${HADOOP_RELEASE_NAME}/logs"
	echo -e ${CMD}
	${CMD}
}

function createHadoopDataDirectory() {
	echo -e "\nCreating Hadoop data directory ${HADOOP_DATA_DIRECORY}..."
	CMD="mkdir -p ${HADOOP_DATA_DIRECORY}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nCreating Hadoop namenode directory ${HADOOP_DATA_DIRECORY_NAMENODE}..."
	CMD="mkdir -p ${HADOOP_DATA_DIRECORY_NAMENODE}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nCreating Hadoop datanode directory ${HADOOP_DATA_DIRECORY_DATANODE}..."
	CMD="mkdir -p ${HADOOP_DATA_DIRECORY_DATANODE}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nChange the owner of the Name Node directory user:group (${HADOOP_USER_HDFS}:${HADOOP_GROUP})..."
	CMD="chown -R ${HADOOP_USER_HDFS}:${HADOOP_GROUP} ${HADOOP_DATA_DIRECORY_NAMENODE}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nCreating Data Node directory ${HADOOP_DATA_DIRECORY_DATANODE}..."
	CMD="sudo mkdir -p ${HADOOP_DATA_DIRECORY_DATANODE}"
	echo -e ${CMD}
	${CMD}
	
	echo -e "\nChange the owner of the Data Node directory to user:group (${HADOOP_USER_HDFS}:${HADOOP_GROUP})..."
	CMD="chown -R ${HADOOP_USER_HDFS}:${HADOOP_GROUP} ${HADOOP_DATA_DIRECORY_DATANODE}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nCreating temporary directory ${HADOOP_BASE_TMP_DIRECORY}..."
	CMD="sudo mkdir -p ${HADOOP_BASE_TMP_DIRECORY}"
	echo -e ${CMD}
	${CMD}
	
	echo -e "\nChange the owner of the temporary directory to user:group (${HADOOP_USER_HDFS}:${HADOOP_GROUP})..."
	CMD="chown -R ${HADOOP_USER_HDFS}:${HADOOP_GROUP} ${HADOOP_BASE_TMP_DIRECORY}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nGiving write permissions for group (${HADOOP_GROUP}) for temporary directory..."
	CMD="chmod g+w ${HADOOP_BASE_TMP_DIRECORY}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
}

function setHadoopEnvironmentStandAlone() {
	echo -e "\nSetting Hadoop environment for shell..."

	CMD="echo 'export HADOOP_HOME=${HADOOP_HOME}' > ${HADOOP_ENV_SH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'export HADOOP_HOME=${HADOOP_HOME}' > ${HADOOP_ENV_SH}"

	CMD="echo 'export PATH=${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin:\${PATH}' >> ${HADOOP_ENV_SH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'export PATH=${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin:\${PATH}' >> ${HADOOP_ENV_SH}"

	CMD="chmod +x ${HADOOP_ENV_SH}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}

	echo -e "\nSetting Hadoop environment for cshell..."

	CMD="echo 'setenv HADOOP_HOME ${HADOOP_HOME}' > ${HADOOP_ENV_CSH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'setenv HADOOP_HOME ${HADOOP_HOME}' > ${HADOOP_ENV_CSH}"

	CMD="echo 'setenv PATH ${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin:\${PATH}' >> ${HADOOP_ENV_CSH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'setenv PATH ${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin:\${PATH}' >> ${HADOOP_ENV_CSH}"

	CMD="chmod +x ${HADOOP_ENV_CSH}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nCreating hadoop configuration directory..."
	CMD="mkdir -p ${HADOOP_CONF_DIR}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nConfiguring Hadoop environment..."
	echo -e "\nSeting default configuration..."
	CMD="cp ${HADOOP_HOME}/etc/hadoop/hadoop-env.sh ${HADOOP_CONF_DIR}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nSeting JAVA_HOME configuration..."
	CMD="sed -i \"/export JAVA_HOME/c\export JAVA_HOME=${JAVA_HOME}\" ${HADOOP_CONF_FILE}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "${CMD}"

	echo -e "\nSeting HADOOP_HOME configuration..."
	CMD="sed -i \"/export HADOOP_HOME/c\export HADOOP_HOME=${HADOOP_HOME}\" ${HADOOP_CONF_FILE}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "${CMD}"
}

function setHadoopEnvironment() {
	echo -e "\nSetting Hadoop environment for shell..."

	CMD="echo 'export HADOOP_HOME=${HADOOP_HOME}' > ${HADOOP_ENV_SH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'export HADOOP_HOME=${HADOOP_HOME}' > ${HADOOP_ENV_SH}"
	
	CMD="echo 'export HADOOP_MAPRED_HOME=${HADOOP_MAPRED_HOME}' >> ${HADOOP_ENV_SH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'export HADOOP_MAPRED_HOME=${HADOOP_MAPRED_HOME}' >> ${HADOOP_ENV_SH}"

	CMD="echo 'export HADOOP_CONF_DIR=${HADOOP_CONF_DIR}' >> ${HADOOP_ENV_SH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'export HADOOP_CONF_DIR=${HADOOP_CONF_DIR}' >> ${HADOOP_ENV_SH}"

	CMD="echo 'export PATH=\${PATH}:${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin' >> ${HADOOP_ENV_SH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'export PATH=\${PATH}:${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin' >> ${HADOOP_ENV_SH}"

	CMD="chmod +x ${HADOOP_ENV_SH}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}
	
	echo -e "\nSetting Hadoop environment for cshell..."

	CMD="echo 'setenv HADOOP_HOME ${HADOOP_HOME}' > ${HADOOP_ENV_CSH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'setenv HADOOP_HOME ${HADOOP_HOME}' > ${HADOOP_ENV_CSH}"
	
	CMD="echo 'setenv HADOOP_MAPRED_HOME ${HADOOP_MAPRED_HOME}' >> ${HADOOP_ENV_CSH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'setenv HADOOP_MAPRED_HOME ${HADOOP_MAPRED_HOME}' >> ${HADOOP_ENV_CSH}"

	CMD="echo 'setenv HADOOP_CONF_DIR ${HADOOP_CONF_DIR}' >> ${HADOOP_ENV_CSH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'setenv HADOOP_CONF_DIR ${HADOOP_CONF_DIR}' >> ${HADOOP_ENV_CSH}"

	CMD="echo 'setenv PATH \${PATH}:${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin' >> ${HADOOP_ENV_CSH}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "echo 'setenv PATH \${PATH}:${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin' >> ${HADOOP_ENV_CSH}"

	CMD="chmod +x ${HADOOP_ENV_CSH}"
	echo -e "sudo ${CMD}"
	sudo ${CMD}

	echo -e "\nConfiguring users in Hadoop configuration file..."
	CMD="echo 'export HDFS_NAMENODE_USER=${HADOOP_USER_HDFS}' >> ${HADOOP_CONF_FILE}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "${CMD}"

	CMD="echo 'export HDFS_DATANODE_USER=${HADOOP_USER_HDFS}' >> ${HADOOP_CONF_FILE}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "${CMD}"

	CMD="echo 'export HDFS_SECONDARYNAMENODE_USER=${HADOOP_USER_HDFS}' >> ${HADOOP_CONF_FILE}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "${CMD}"

	CMD="echo 'export YARN_RESOURCEMANAGER_USER=${HADOOP_USER_YARN}' >> ${HADOOP_CONF_FILE}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "${CMD}"

	CMD="echo 'export YARN_NODEMANAGER_USER=${HADOOP_USER_YARN}' >> ${HADOOP_CONF_FILE}"
	echo -e "sudo bash -c \"${CMD}\""
	sudo bash -c "${CMD}"
}

function createUser() {
	_USER=$1
	_SERVICE_NAME=$2
	_PASSWORD=$3
		
	echo -e "\nCreating user account (${_USER}) for ${_SERVICE_NAME} service..."
	CMD="useradd -c 'User for ${_SERVICE_NAME} Service' -s /bin/bash -d /home/${_USER} -m -g ${HADOOP_GROUP} ${_USER}"
	echo -e "sudo ${CMD}"
	sudo bash -c "${CMD}"
	
	echo -e "\nSetting password for ${_USER}..."
	CMD="echo -e \"${_PASSWORD}\n${_PASSWORD}\n\" | passwd ${_USER}"
	echo -e "sudo ${CMD}"
	sudo bash -c "${CMD}"

	echo -e "\nConfiguring SSH account for user ${_USER}..."

	CMD="bash -c 'ssh-keygen -t rsa -f ~/.ssh/id_rsa -q -N \"\" '"
	echo -e "sudo -H -u ${_USER} ${CMD}"
	sudo -H -u ${_USER} bash -c "${CMD}"

	CMD="bash -c 'cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys'"
	echo -e "sudo -H -u ${_USER} ${CMD}"
	sudo -H -u ${_USER} bash -c "${CMD}"
	
	CMD="echo 'JAVA_HOME=${JAVA_HOME}' > ~/.ssh/environment"
	echo -e "sudo -H -u ${_USER} ${CMD}"
	sudo -H -u ${_USER} bash -c "${CMD}"
	
	CMD="echo 'HADOOP_HOME=${HADOOP_HOME}' >> ~/.ssh/environment"
	echo -e "sudo -H -u ${_USER} ${CMD}"
	sudo -H -u ${_USER} bash -c "${CMD}"
	
	CMD="echo 'HADOOP_CONF_FILE=${HADOOP_CONF_FILE}' >> ~/.ssh/environment"
	echo -e "sudo -H -u ${_USER} ${CMD}"
	sudo -H -u ${_USER} bash -c "${CMD}"
	
	CMD="echo 'HADOOP_CONF_DIR=${HADOOP_CONF_DIR}' >> ~/.ssh/environment"
	echo -e "sudo -H -u ${_USER} ${CMD}"
	sudo -H -u ${_USER} bash -c "${CMD}"
}

function createServiceConfigFile() {
	_SETTINGS=$1
	_SERVICE_NAME=$2
	_SERVICE_FILE=$3
	_SERVICE_DIRECTORY=$4

	echo -e "\nCreating configuration for ${_SERVICE_NAME} in file ${_SERVICE_DIRECTORY}/${_SERVICE_FILE}..."
	echo -e ${_SETTINGS}
	
	_SETTINGS_TEMP=/tmp/${_SERVICE_FILE}.tmp
	
	echo ${_SETTINGS} > ${_SETTINGS_TEMP}
	sudo cp ${_SETTINGS_TEMP} ${_SERVICE_DIRECTORY}/${_SERVICE_FILE}
	sudo rm -f ${_SETTINGS_TEMP}
}

function createSystemdFile() {
	_SETTINGS=$1
	_SERVICE_NAME=$2
	_SERVICE_FILE=$3
	_SERVICE_DIRECTORY=$4

	echo -e "\nCreating configuration for Systemd Service in file ${_SERVICE_DIRECTORY}/${_SERVICE_FILE}..."
	echo -e ${_SETTINGS}
	
	_SETTINGS_TEMP=/tmp/${_SERVICE_FILE}.tmp
	
	echo ${_SETTINGS} > ${_SETTINGS_TEMP}
	sudo cp ${_SETTINGS_TEMP} ${_SERVICE_DIRECTORY}/${_SERVICE_FILE}
	sudo rm -f ${_SETTINGS_TEMP}
	
	CMD="systemctl daemon-reload"
	echo -e "sudo ${CMD}"
	sudo bash -c "${CMD}"
		
	CMD="systemctl enable ${_SERVICE_NAME}"
	echo -e "sudo ${CMD}"
	sudo bash -c "${CMD}"
}

function removeService() {
	_SERVICE_NAME=$1
	_SERVICE_FILE=$2
	_SERVICE_DIRECTORY=$3
	
	sudo systemctl stop ${_SERVICE_NAME}
	sudo systemctl disable ${_SERVICE_NAME}
	sudo rm ${_SERVICE_DIRECTORY}/${_SERVICE_FILE}
	sudo systemctl daemon-reload
	sudo systemctl reset-failed
}

function createNodesFile() {
	_HOSTS=$1
	_NAME=$2
	_FILE=$3
	_FILE_DIRECTORY=$4

	echo -e "\nCreating nodes files for ${_NAME} in file ${_FILE_DIRECTORY}/${_FILE}..."
	echo -e ${_HOSTS}
	
	_HOSTS_TEMP=/tmp/${_FILE}.tmp
	
	echo ${_HOSTS} > ${_HOSTS_TEMP}
	sudo cp ${_HOSTS_TEMP} ${_FILE_DIRECTORY}/${_FILE}
	sudo rm -f ${_HOSTS_TEMP}
}

function showHadoopVersion() {
	echo -e "\nHadoop version:"
	${HADOOP_HOME}/bin/hadoop version
}
