#!/bin/bash

source 01-hadoopDefs.sh

_hdFull=${HADOOP_BASE_DIRECTORY}/${HADOOP_RELEASE_NAME}
_hdLink=${HADOOP_HOME}

echo -e "\nRemoving Hadoop files..."

echo -e "\nRemoving Hadoop directory (${_hdFull})..."
sudo rm -rf ${_hdFull}

echo -e "\nRemoving Hadoop symbolic name (${_hdLink})..."
sudo rm -rf ${_hdLink}

echo -e "\nRemoving Hadoop configuration..."

echo -e "\nRemoving Hadoop configuration directory (${HADOOP_CONF_DIR})..."
sudo rm -rf ${HADOOP_CONF_DIR}

echo -e "\nRemoving Hadoop environment shell settings (${HADOOP_ENV_SH})..."
sudo rm -rf ${HADOOP_ENV_SH}

echo -e "\nRemoving Hadoop environment cshell settings (${HADOOP_ENV_CSH})..."
sudo rm -rf ${HADOOP_ENV_CSH}
