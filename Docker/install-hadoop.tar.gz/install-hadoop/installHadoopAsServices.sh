#!/bin/bash

04-hadoopPseudoDistributed-Install.sh | tee ~/installHadoopAsServices.log

06-hadoopPseudoDistributed-HDFS-Format.sh 2>&1 | tee -a ~/installHadoopAsServices.log

07-hadoopPseudoDistributed-Start.sh 2>&1 | tee -a ~/installHadoopAsServices.log

08-hadoopPseudoDistributed-HDFS-Init.sh 2>&1 | tee -a ~/installHadoopAsServices.log

09-hadoopPseudoDistributed-ShowUI.sh 2>&1 | tee -a ~/installHadoopAsServices.log

12-hadoop-ServicesOnBoot.sh 2>&1 | tee -a ~/installHadoopAsServices.log
