#!/bin/bash

source 01-hadoopDefs.sh

03-hadoopStandAlone-Erase.sh

echo -e "\nRemoving Hadoop group (${HADOOP_GROUP})..."
sudo groupdel -f ${HADOOP_GROUP}

echo -e "\nRemoving Hadoop users..."
sudo userdel -r -f ${HADOOP_USER_MR}
sudo userdel -r -f ${HADOOP_USER_HDFS}
sudo userdel -r -f ${HADOOP_USER_YARN}

echo -e "\nRemoving temporaty files..."
sudo rm -rf /tmp/hadoop*
sudo rm -rf /tmp/hsperfdata_hdfs

echo -e "\nRemoving Hadoop data directory"
sudo rm -rf ${HADOOP_DATA_DIRECORY}

echo -e "\nRemoving Hadoop home directory"
sudo rm -rf ${HADOOP_HOME}
