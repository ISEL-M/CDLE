#!/bin/bash

#mvn clean package install -DskipTests
mvn clean package install
